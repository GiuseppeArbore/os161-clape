/* Automatically generated; do not edit */
#ifndef _OPT_TEST_H_
#define _OPT_TEST_H_
#define OPT_TEST 1
#endif /* _OPT_TEST_H_ */
