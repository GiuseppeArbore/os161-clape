thread.o: ../../thread/thread.c ../../include/types.h \
 ../../include/kern/types.h includelinks/kern/machine/types.h \
 includelinks/machine/types.h ../../include/kern/errno.h \
 ../../include/lib.h ../../include/cdefs.h opt-noasserts.h \
 ../../include/array.h ../../include/cpu.h ../../include/spinlock.h \
 ../../include/hangman.h opt-hangman.h includelinks/machine/spinlock.h \
 ../../include/threadlist.h includelinks/machine/vm.h ../../include/spl.h \
 ../../include/wchan.h ../../include/thread.h \
 includelinks/machine/thread.h ../../include/setjmp.h \
 includelinks/kern/machine/setjmp.h ../../include/threadprivate.h \
 ../../include/proc.h ../../include/synch.h ../../include/current.h \
 includelinks/machine/current.h ../../include/addrspace.h \
 ../../include/vm.h opt-dumbvm.h ../../include/elf.h \
 includelinks/machine/elf.h ../../include/pt.h opt-debug.h \
 ../../include/vm_tlb.h ../../include/types.h ../../include/syscall.h \
 opt-fork.h ../../include/proc.h ../../include/swapfile.h \
 ../../include/addrspace.h ../../include/kern/fcntl.h ../../include/uio.h \
 ../../include/kern/iovec.h ../../include/vnode.h \
 ../../include/copyinout.h ../../include/lib.h ../../include/vfs.h \
 ../../include/vmstats.h ../../include/synch.h opt-sw_list.h \
 ../../include/vm.h ../../include/spl.h ../../include/current.h \
 ../../include/mainbus.h ../../include/vnode.h
