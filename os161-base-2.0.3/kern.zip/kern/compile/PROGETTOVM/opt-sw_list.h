/* Automatically generated; do not edit */
#ifndef _OPT_SW_LIST_H_
#define _OPT_SW_LIST_H_
#define OPT_SW_LIST 1
#endif /* _OPT_SW_LIST_H_ */
