/* Automatically generated; do not edit */
#ifndef _OPT_DEBUG_H_
#define _OPT_DEBUG_H_
#define OPT_DEBUG 0
#endif /* _OPT_DEBUG_H_ */
