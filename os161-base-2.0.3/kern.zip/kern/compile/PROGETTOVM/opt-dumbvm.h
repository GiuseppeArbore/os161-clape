/* Automatically generated; do not edit */
#ifndef _OPT_DUMBVM_H_
#define _OPT_DUMBVM_H_
#define OPT_DUMBVM 0
#endif /* _OPT_DUMBVM_H_ */
