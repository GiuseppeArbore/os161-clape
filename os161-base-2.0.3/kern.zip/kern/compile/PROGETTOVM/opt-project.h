/* Automatically generated; do not edit */
#ifndef _OPT_PROJECT_H_
#define _OPT_PROJECT_H_
#define OPT_PROJECT 1
#endif /* _OPT_PROJECT_H_ */
