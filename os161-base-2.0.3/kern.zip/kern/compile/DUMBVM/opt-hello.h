/* Automatically generated; do not edit */
#ifndef _OPT_HELLO_H_
#define _OPT_HELLO_H_
#define OPT_HELLO 0
#endif /* _OPT_HELLO_H_ */
